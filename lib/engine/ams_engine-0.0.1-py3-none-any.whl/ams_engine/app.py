#!/usr/bin/env python
# -*- coding: utf-8 -*-
from gevent import monkey
monkey.patch_all()

import base64
import six
import numpy as np
import traceback
import json
import time
from flask import Flask, request, jsonify
from util.log import Logger


app = Flask(__name__)


@app.route('/health', methods=['GET'])
def health():
    return jsonify({'status': 'UP'})


@app.route('/endpoints', methods=['GET'])
def endpoints():
    return jsonify(engine.endpoints())


@app.route('/algo/<processor_name>', methods=['POST'])
def process(processor_name):
    return get_response(processor_name)


def get_response(processor_name):
    try:
        start_time = time.time()
        result = call_algorithm(processor_name)
        duration = time.time() * 1000 - start_time * 1000
        if is_binary(result):
            content_type = 'binary'
            result = base64.b64encode(result)
            # In python 3, the encoded result is a byte array which cannot be
            # json serialized so we need to turn this into a string.
            if not isinstance(result, six.string_types):
                result = str(result, 'utf-8')
        elif isinstance(result, six.string_types) or isinstance(result, six.text_type):
            content_type = 'text'
        else:
            content_type = 'json'
        response_string = json.dumps({
            'result': True,
            'data': result,
            'metadata': {
                'duration': duration,
                'content_type': content_type
            }
        }, ensure_ascii=False, cls=NumpyEncoder)
    except Exception as e:
        if hasattr(e, 'error_type'):
            error_type = e.error_type
        else:
            error_type = 'AlgoError'
        response_string = json.dumps({
            'result': False,
            'data': {
                'message': str(e),
                'stacktrace': traceback.format_exc(),
                'error_type': error_type
            }
        }, ensure_ascii=False)
        logger.error("[Exception] %s", response_string)
        logger.warn("异常排查建议：（1）检查服务启动历史日志；（2）检查是否缺少依赖包；（3）请求参数不正确；（4）检查是否操作系统环境兼容性问题")
    return response_string


def call_algorithm(processor_name):
    content_type = request.content_type
    logger.info("request contentType: %s ,content_length: %d", content_type, request.content_length)
    if content_type.startswith("application/json"):
        data = request.get_json()
    elif content_type.startswith('text/plain') or content_type.startswith('multipart/form-data'):
        if is_binary(request.get_data()):
            data = request.get_data().decode('utf-8')
        else:
            data = request.get_data()
    elif content_type == 'application/octet-stream' or content_type == 'binary':
        data = wrap_binary_data(request.data)
    else:
        raise Exception("Invalid content_type: {}".format(content_type))
    result = engine.inference(data, processor_name)
    return result


def is_binary(arg):
    return isinstance(arg, base64.bytes_types)


def wrap_binary_data(data):
    return bytes(data)


# np array转json
class NumpyEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, np.integer):
            return int(obj)
        if isinstance(obj, np.floating):
            return float(obj)
        if isinstance(obj, np.ndarray):
            return obj.tolist()
        if isinstance(obj, bytes):
            return str(obj, encoding='utf-8')
        return json.JSONEncoder.default(self, obj)

import os
from service_engine import ServiceEngine
if __name__ == '__main__':
    processor_path = 'D:/coding park/processor-customized/'
    model_path = 'model'
else:
    processor_path = os.getenv('PROCESSOR_PATH')
    model_path = os.getenv('default_model_path')
logger = Logger(log_path=processor_path+"/logs").getLogger(__name__)
engine = ServiceEngine(processor_path=processor_path,model_path=model_path)
# app.run('0.0.0.0', 8088, debug=False, threaded=True)