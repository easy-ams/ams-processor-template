#!/usr/bin/env python
# -*- coding: utf-8 -*-

import os
import sys
import traceback
import json
import time
from util.log import Logger
from exception.algo_exception import AlgoException
from exception.processor_exception import ProcessorException
from exception.validate_exception import ValidateException


def load_endpoint(path):
    with open(path, 'r') as load_f:
        arr = json.load(load_f)
    return arr


class ServiceEngine:

    def __init__(self, processor_path=None, model_path=None, processor_type='customized'):
        logger = Logger(log_path=processor_path+"/logs").getLogger(__name__)
        if processor_path:
            logger.info('processor path: %s', processor_path)
        else:
            # 输出参数异常
            logger.error('processor path is none')
            raise ValidateException('param processor_path is none, terminated')
        init_start_time = time.time()
        # 模型路径
        logger.info('model path: %s', model_path)
        self.endpoint_arr = load_endpoint(processor_path + "/conf/endpoint.json")
        try:
            logger.info("开始启动服务")
            sys.path.append(processor_path + "/src")
            logger.info("初始推理代码")
            # 读取endpoint配置，初始化类
            self.instance_dict = {}
            for endpoint in self.endpoint_arr:
                script_name = endpoint['processor_script_name']
                class_name = endpoint['processor_class_name']
                logger.info('instance %s ==> %s', script_name, class_name)
                ext_module = __import__(script_name)
                cls = getattr(ext_module, class_name)
                instance = cls(model_path)
                logger.info(dir(ext_module))
                self.instance_dict[script_name] = instance
            duration = time.time() * 1000 - init_start_time * 1000
            logger.info('初始完成，耗时:%s ms', duration)
        except Exception as e:
            logger.warn("算法服务初始化异常,请根据异常日志分析是否存在依赖包缺失,依赖版本兼容性错误,模型加载失败,代码不规范等原因")
            logger.error("异常信息：%s , %s", str(e), traceback.format_exc())
            raise ProcessorException(message='启动异常 '+str(e))

    def inference(self, data, processor_name):
        if processor_name in self.instance_dict:
            result = self.instance_dict[processor_name].inference(data)
        else:
            raise ValidateException(message='路由名称不存在:'+processor_name)
        return result

    def endpoints(self):
        return self.endpoint_arr
