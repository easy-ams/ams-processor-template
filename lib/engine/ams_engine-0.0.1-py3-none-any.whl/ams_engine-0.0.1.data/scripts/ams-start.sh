#!/bin/bash

echo "=====>启动开始"
#推理代码包路径
PROCESSOR_PATH=$1
PORT=$2
WORKER_NUM=$3
REQUEST_MAX_TIMEOUT=$4

if [ ! -n "${PROCESSOR_PATH}" ];then
  echo "缺少参数PROCESSOR_PATH"
  exit 1
fi
#配置参数作为环境变量
for line in $(cat ${PROCESSOR_PATH}/conf/config.properties|sed '/^$/d'|sed '/#/d')
do
    export ${line}
    echo ${line}
done

if [ ! -n "${PORT}" ];then
  echo "使用默认端口号8088"
  PORT=8088
fi
if [ ! -n "${WORKER_NUM}" ];then
  echo "使用默认进程数1"
  WORKER_NUM=1
fi
if [ ! -n "${REQUEST_MAX_TIMEOUT}" ];then
  echo "使用默认超时时间60s"
  REQUEST_MAX_TIMEOUT=60
fi
#创建日志目录
mkdir -p ${PROCESSOR_PATH}/logs
export PROCESSOR_PATH=${PROCESSOR_PATH}
APP_DIR=`python -c "import ams_engine;print(ams_engine.__path__[0])"`
echo ${APP_DIR}
echo "启动进程"
nohup gunicorn -w ${WORKER_NUM} --threads 20 \
  -t ${REQUEST_MAX_TIMEOUT} \
  -b 0.0.0.0:${PORT} \
  --worker-class gevent \
  --keep-alive 5 \
  --pid ${PROCESSOR_PATH}/logs/gunicorn.pid \
  --access-logfile ${PROCESSOR_PATH}/logs/access.log \
  --error-logfile ${PROCESSOR_PATH}/logs/error-access.log \
  --worker-tmp-dir ${PROCESSOR_PATH} \
  --chdir ${APP_DIR} \
  -e PROCESSOR_PATH=${PROCESSOR_PATH} \
  app:app >> ${PROCESSOR_PATH}/logs/nohup.log 2>&1 &
if [ $? -ne 0 ];then
  echo '启动命令执行失败!'
  exit 1
fi
#sleep 3s
sleep 3
echo "启动完成"
echo "=====>启动结束"
exit 0