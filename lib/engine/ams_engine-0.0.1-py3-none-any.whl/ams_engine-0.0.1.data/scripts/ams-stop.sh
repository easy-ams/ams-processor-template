#!/bin/bash
port=$1
#获取指定端口进程号
pid=$(lsof -i:${port}|awk '{print $2}'|awk 'NR==2{print}')
if [ -n "${pid}" ];then
  kill -9 ${pid}
  echo "终止进程:${pid}"
fi
